

# 说明

1. 添加点击更改文字颜色功能

![red](img/1.png)![black](img/2.png)

2. 添加用户注册页面，提交时弹窗显示用户名。

项目repo：https://github.com/Dianaaaa/SE228-Web-developing

# 运行方法:

```
npm install -g http-server
cd build 
http-server
```

然后访问http://localhost:8080

# 页面：

http://localhost:8080     首页

http://localhost:8080/view      书籍浏览页面

http://localhost:8080/detail      书籍详情页面

http://localhost:8080/signup 	用户注册页面

# 作者信息

钱星月

516072910066

F1703701

