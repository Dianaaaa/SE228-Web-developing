# 说明

使用了vue和sass开发，build1和build2是npm run build打包的产物。由于再写一个css太费时间，所以build2只是在build1的基础上更改了配色方案。

项目repo：https://github.com/Dianaaaa/SE228-Web-developing

# 运行方法:

```
npm install -g http-server
cd build1 
http-server
```

然后访问http://localhost:8080

build12如法炮制

# 页面：

http://localhost:8080     首页

http://localhost:8080/view      书籍浏览页面

http://localhost:8080/detail      书籍详情页面

# 作者信息

钱星月

516072910066

F1703701

